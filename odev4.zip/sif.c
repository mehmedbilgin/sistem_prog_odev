// Fatih Mehmed Bilgin - 170419043 - Sistem Programlama Hafta 4 Odev 4

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char *argv[]) {
	int result, errno;

	FILE *fp;
	int line_num = 1;
	int find_result = 0;
	char temp[512];
	char *str = argv[1];
	char *fname = argv [2];
	int i,j ; 
	int len = strlen(str);
	
	//gcc users
	if((fp = fopen(fname, "r")) == NULL) {
		return(-1);
	}

	

	while(fgets(temp, 512, fp) != NULL) {
		i = 0;
		while(temp[i] != '\n'){
			if(temp[i] == str[0]){
				for(j=1;j<len;j++){
					if(temp[i+j] != str[j]){
						break;
					}
					if(j == (len-1)){
						printf("A match found on %d. line %d. column \n", line_num,(i+1));
					}
				}
			}
			i++;
		}
		
		line_num++;
	}

	
	
	
	if(fp) {
		fclose(fp);
	}
   	return(0);
}
