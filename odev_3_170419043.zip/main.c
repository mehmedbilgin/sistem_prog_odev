/*Fatih Mehmed Bilgin - 170419043 - Sistem Programlama Odev-3*/

#include <stdio.h>
#include <stdint.h>
#include "GetPrime.h"

int main(){
    uint16_t girdi;
    int kontrol = 1;
    while(kontrol){
        printf("Deger giriniz\n");
        scanf("%hd", &girdi);
        if(girdi>0){
            kontrol = 0;
        }
    }
    uint64_t deger = GetPrime(girdi);
    printf("%hd. asal sayı : %ld",girdi,deger);
    return 0;
}
