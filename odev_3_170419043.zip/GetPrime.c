/*Fatih Mehmed Bilgin - 170419043 - Sistem Programlama - Odev3*/

#include "GetPrime.h"
#include <stdint.h>

uint64_t GetPrime(uint16_t sayi){
    uint16_t i,c,d;
    uint64_t donus;
    int sayac = 0;
    
    uint16_t istenen = sayi;
    for(i=2;i<=1000000000;i++){
        d=1;
        for (c=2;c<i;c++){
            if (i%c==0){
                d=0;
            }
        }

        if (d==1) {
            sayac++;
        }
        if(sayac == istenen){
            donus = i;
            return donus;
            break;
        }
    }
}
