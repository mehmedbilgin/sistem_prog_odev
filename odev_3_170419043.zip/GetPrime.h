#include <stdint.h>

uint64_t GetPrime(uint16_t sayi);
